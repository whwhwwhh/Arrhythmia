
#set up tunning parameters for selected models 
classifictaion_models = {
    'LogisticRegression':
        {'maxIter':30, 
         'featuresCol':'selectedFeatures', 
         'labelCol':'label', 
         'regParam':0.1, 
         'tuning_params':{
             'maxIter':[10, 20, 30],
             'regParam': [0.1, 0.01]
         }}, 
    'DecisionTreeClassifier':{
        "maxDepth":4, 
        'featuresCol':'features', 
        'labelCol':'label', 
        'tuning_params':{
             'maxIter':[10, 20, 30],
             'maxDepth': [4, 6, 8]
         }
         }, 
    'RandomForestClassifier':{
        "numTrees":10, 
        'featuresCol':'features', 
        'labelCol':'label', 
        'tuning_params':{
             'maxIter':[10, 20, 30],
             'numTrees': [6, 8 ,10, 12]
         }
        }, 
    'GBTClassifier':{
        "maxDepth":4, 
        'featuresCol':'features', 
        'labelCol':'label', 
        'tuning_params':{
             'maxIter':[10, 20, 30],
             'maxDepth': [4, 6, 8]
         }
        }
    }
